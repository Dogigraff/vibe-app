"use client";

import { MapShell } from "@/features/map/MapShell";

export default function MapPage() {
  return <MapShell />;
}
